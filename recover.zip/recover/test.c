// recover a jpg files from a memori

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <cs50.h>

int main(int argc, char *argv[])
{
    // ensure proper usage
    if (argc != 2)
    {
        fprintf(stderr, "Usage: ./recover image\n");
        return 1;
    }

    //save infile memory
    char *infile = argv[1];

    // open input file
    FILE *inptr = fopen(infile, "r");
    if (inptr == NULL)
    {
        //fprintf(stderr, "Could not open %s.\n", infile);
        return 1;
    }

    //create a buffer for the jpeg
    unsigned char buffer[512];
    int i = 0;

    //create a file img out of the loop
    FILE *img;

    //start reading the card in 512 blocks
    while (fread(&buffer, 1, 512, inptr) == 512)
    {
        //look for the jpg and iniciate the writing
        int j = 0;
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0)
        {
            j = 1;
        }
        //
        if (i == 0 && j == 1)
        {
            //write the name of the new jpg and open it
            char filename[8];
            sprintf(filename, "%03i.jpg", i);
            img = fopen(filename, "w");

            i++;
        }

        if (i > 0 && j == 1)
        {
            //close the jpg
            fclose(img);

            //write the name of the new jpg and open it
            char filename[8];
            sprintf(filename, "%03i.jpg", i);
            img = fopen(filename, "w");

            //iniciate the write of the jpg
            i++;
        }

        if (i > 0)
        {
            fwrite(&buffer, 1, 512, img);
        }
    }

    // close infile
    fclose(inptr);

    // close outfile
    fclose(img);

    // success
    return 0;
}